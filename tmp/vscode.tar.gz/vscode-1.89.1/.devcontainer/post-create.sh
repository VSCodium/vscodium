#!/bin/sh

yarn install --network-timeout 180000
yarn electron
